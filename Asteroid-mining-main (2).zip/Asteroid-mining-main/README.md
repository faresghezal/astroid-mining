# asteroid_mining
Software project lab 2022 | Team 200-OK

module AsteroidMining {
	requires java.desktop; 
}
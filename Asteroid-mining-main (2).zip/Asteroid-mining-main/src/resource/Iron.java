package resource;

import neighbour.Asteroid;

public class Iron extends Resource {
//R10
	public Iron()  {
		type = "Iron";
	}

	@Override
	public void exposed(Asteroid a) {
		
	}
	
}

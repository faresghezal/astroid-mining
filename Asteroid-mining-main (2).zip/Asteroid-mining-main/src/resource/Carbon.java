package resource;

import neighbour.Asteroid;

public class Carbon extends Resource { //R10
	public Carbon()  {
		type = "Carbon";
	}
	@Override
	public void exposed(Asteroid a) {
		
	}
}
